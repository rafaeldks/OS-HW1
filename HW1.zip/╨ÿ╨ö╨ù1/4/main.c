#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>

const int buffer_size = 5500;

// Функция, которая находит необходимую подстроку в строке
char *findSequence(char *input, int N) {
    int n = strlen(input);
    if (N <= 0) {
        return "None";
    }
    int ind = -1;
    for (int i = 0; i < n - N + 1; i++) {
        int found_sequence = 1;
        for (int j = i + 1; j < i + N; j++) {
            if (input[j] <= input[j - 1]) {
                found_sequence = 0;
            }
        }
        if (found_sequence) {
            ind = i;
        }
    }
    if (ind != -1) {
        // Копируем подходящую подстроку в новую строку и возвращаем
        char *result = (char *) malloc(N * sizeof(char));
        strncpy(result, input + ind, N);
        result[N] = '\0';
        return result;
    }
    // На случай, если подходящей подстроки не было найдено:
    return "None";
}

int main(int argc, char **argv) {
    int read_pipe[2];
    int write_pipe[2];
    int read_pid = 0;
    int write_pid;
    int processing_pid;
    char *read_file = argv[1];
    char *write_file = argv[2];
    int N = atoi(argv[3]);

    int main_pid = getpid();  // Получаем цифровой идентификатор текущего процесса
    if ((pipe(read_pipe) < 0) || (pipe(write_pipe) < 0)) {
        printf("Error: cannot create pipe");
        exit(-1);
    }

    if (main_pid == getpid()) {
        read_pid = fork();
        if (read_pid == 0) {
            read_pid = getpid();
        }
    }

    if (main_pid == getpid()) {
        processing_pid = fork();
        if (processing_pid == 0) {
            processing_pid = getpid();
        }
    }

    if (main_pid == getpid()) {
        write_pid = fork();
        if (write_pid == 0) {
            write_pid = getpid();
        }
    }

    if (read_pid == getpid()) {
        int file_descriptor = open(read_file, O_RDONLY);
        char read_buffer[buffer_size];
        ssize_t read_bytes;
        if (file_descriptor < 0) {
            printf("Error: cannot open file");
            exit(-1);
        }
        read_bytes = read(file_descriptor, read_buffer, buffer_size);
        if (read_bytes == -1) {
            printf("Error: cannot write this file");
            exit(-1);
        }
        if (close(file_descriptor) < 0) {
            printf("Error: cannot close file");
        }

        read_buffer[read_bytes] = '\0';

        close(read_pipe[0]);

        int write_size = write(read_pipe[1], read_buffer, read_bytes);
        if (write_size != read_bytes) {
            printf("Error: cannot write all strings");
            exit(-1);
        }
        close(read_pipe[1]);
    }
    if (processing_pid == getpid()) {
        char get_buffer[buffer_size];
        close(read_pipe[1]);
        int size = read(read_pipe[0], get_buffer, buffer_size);
        if (size < 0) {
            printf("Error: cannot read string");
            exit(-1);
        }
        close(read_pipe[0]);

        char *subsequence = findSequence(get_buffer, N);

        close(write_pipe[0]);

        int write_size = write(write_pipe[1], subsequence, strlen(subsequence));
        if (write_size != strlen(subsequence)) {
            printf("Error: cannot write all strings");
            exit(-1);
        }

        close(write_pipe[1]);
    }
    if (write_pid == getpid()) {
        char get_buffer[2 * buffer_size];
        close(write_pipe[1]);
        int size = read(write_pipe[0], get_buffer, 2 * buffer_size);
        if (size < 0) {
            printf("Error: cannot read string");
            exit(-1);
        }
        close(write_pipe[0]);

        printf("%s\n", get_buffer);

        int fd = open(write_file, O_WRONLY | O_CREAT, 0666);
        if (fd < 0) {
            printf("Error: cannot open file");
            exit(-1);
        }
        size = write(fd, get_buffer, strlen(get_buffer));
        if (size != strlen(get_buffer)) {
            printf("Error: cannot write all strings");
            exit(-1);
        }
        if (close(fd) < 0) {
            printf("Error: cannot close file");
        }
    }

    return 0;
}