#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>

const int buffer_size = 5500;

// Функция, которая находит необходимую подстроку в строке
char *findSequence(char *input, int N) {
    int n = strlen(input);
    if (N <= 0) {
        return "None";
    }
    int ind = -1;
    for (int i = 0; i < n - N + 1; i++) {
        int found_sequence = 1;
        for (int j = i + 1; j < i + N; j++) {
            if (input[j] <= input[j - 1]) {
                found_sequence = 0;
            }
        }
        if (found_sequence) {
            ind = i;
        }
    }
    if (ind != -1) {
        // Копируем подходящую подстроку в новую строку и возвращаем
        char *result = (char *) malloc(N * sizeof(char));
        strncpy(result, input + ind, N);
        result[N] = '\0';
        return result;
    }
    // На случай, если подходящей подстроки не было найдено:
    return "None";
}

int main(int argc, char **argv) {
    char read_fifo[] = "read.fifo";
    char write_fifo[] = "write.fifo";
    int read_pid = 0;
    int write_pid;
    int process_pid;
    char *read_file = argv[1];
    char *write_file = argv[2];
    int N = atoi(argv[3]);
    (void) umask(0);
    int main_pid = getpid();

    if (main_pid == getpid()) {
        read_pid = fork();
        if (read_pid == 0) {
            read_pid = getpid();
        }
    }

    if (main_pid == getpid()) {
        process_pid = fork();
        if (process_pid == 0) {
            process_pid = getpid();
        }
    }

    if (main_pid == getpid()) {
        write_pid = fork();
        if (write_pid == 0) {
            write_pid = getpid();
        }
    }

    if (read_pid == getpid()) {
        int file_descriptor;
        char read_buffer[buffer_size];
        ssize_t read_bytes;
        if ((file_descriptor = open(read_file, O_RDONLY)) < 0) {
            printf("Error: cannot open file");
            exit(-1);
        }
        read_bytes = read(file_descriptor, read_buffer, buffer_size);
        if (read_bytes == -1) {
            printf("Error: cannot write file");
            exit(-1);
        }
        if (close(file_descriptor) < 0) {
            printf("Error: cannot close file");
        }

        read_buffer[read_bytes] = '\0';

        if ((file_descriptor = open(read_fifo, O_WRONLY)) < 0) {
            printf("Error: cannot open FIFO");
            exit(-1);
        }
        int write_size = write(file_descriptor, read_buffer, read_bytes);
        if (write_size != read_bytes) {
            printf("Error: cannot write all string to FIFO");
            exit(-1);
        }
        close(file_descriptor);
    }
    if (process_pid == getpid()) {
        char get_buffer[buffer_size];
        int file_descriptor;

        if ((file_descriptor = open(read_fifo, O_RDONLY)) < 0) {
            printf("Error: cannot open FIFO for reading");
            exit(-1);
        }
        int size = read(file_descriptor, get_buffer, buffer_size);
        if (size < 0) {
            printf("Error: cannot read string");
            exit(-1);
        }
        close(file_descriptor);

        char *subsequence = findSequence(get_buffer, N);

        if ((file_descriptor = open(write_fifo, O_WRONLY)) < 0) {
            printf("Error: cannot open FIFO for writing");
            exit(-1);
        }
        int write_size = write(file_descriptor, subsequence, strlen(subsequence));
        if (write_size != strlen(subsequence)) {
            printf("Error: cannot write all string to FIFO");
            exit(-1);
        }
        close(file_descriptor);

    }
    if (write_pid == getpid()) {
        char get_buffer[2 * buffer_size];
        int file_descriptor;
        int size;

        if ((file_descriptor = open(write_fifo, O_RDONLY)) < 0) {
            printf("Error: cannot open FIFO");
            exit(-1);
        }
        size = read(file_descriptor, get_buffer, 2 * buffer_size);
        if (size < 0) {
            printf("Error: cannot read string");
            exit(-1);
        }
        close(file_descriptor);

        printf("%s\n", get_buffer);

        if ((file_descriptor = open(write_file, O_WRONLY | O_CREAT, 0666)) < 0) {
            printf("Error: cannot open file");
            exit(-1);
        }
        size = write(file_descriptor, get_buffer, strlen(get_buffer));
        if (size != strlen(get_buffer)) {
            printf("Error: cannot write all string");
            exit(-1);
        }
        if (close(file_descriptor) < 0) {
            printf("Error: cannot close file");
        }
    }
}